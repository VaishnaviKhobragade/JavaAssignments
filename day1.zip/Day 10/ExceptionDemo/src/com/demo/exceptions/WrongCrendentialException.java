package com.demo.exceptions;

public class WrongCrendentialException extends Exception {
  public WrongCrendentialException(String msg) {
	  super(msg);
  }
}
