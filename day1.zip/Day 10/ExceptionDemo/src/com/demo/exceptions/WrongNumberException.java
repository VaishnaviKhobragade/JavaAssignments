package com.demo.exceptions;

public class WrongNumberException extends Exception{
	public WrongNumberException(String msg) {
		super(msg);
	}

}
