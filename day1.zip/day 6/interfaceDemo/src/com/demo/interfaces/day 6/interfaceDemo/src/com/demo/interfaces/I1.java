package com.demo.interfaces;

public interface I1 {
	void funct11();
	int funct12();

}
