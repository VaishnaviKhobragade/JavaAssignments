package com.demo.beans;

import com.demo.interfaces.Interface31;

public class Class2 extends Class1 implements Interface31{
         
}
